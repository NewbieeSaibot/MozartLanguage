A implementação utilizada depende da bilbioteca PLY.
Para que o arquivo seja executado, basta alterar o caminho na leitura de arquivo na linha 263 do código.
Uma vez alterado o caminho, basta mandar o Python interpretar o main.py.